#include "../libft.h"
#include "/Users/aazzaoui/Unity-master/src/unity.h"
#include  <ctype.h>

void setUp(void)
{
  /* This is run before EACH TEST */
}
void tearDown(void)
{
}

void test_isalpha(void)
{
    //arrange
    int exp = 0;
    int act = 0; 
    int i = 0;
    //act
    while(i <= 255)
    {
      act = ft_isalpha(i);
      exp = isalpha(i);
      //assert
      TEST_ASSERT_EQUAL_INT32(exp, act);
      i++;
    }
}

int main()
{
  RUN_TEST(test_isalpha);
  return (UnityEnd());
}