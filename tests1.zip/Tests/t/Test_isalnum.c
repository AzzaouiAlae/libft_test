#include "../libft.h"
#include "/Users/aazzaoui/Unity-master/src/unity.h"
#include  <ctype.h>

void setUp(void)
{
  /* This is run before EACH TEST */
}
void tearDown(void)
{
}

void test_isalnum(void)
{
    //arrange
    int exp = 0;
    int act = 0; 
    int i = 0;
    //act
    while(i <= 255)
    {
      act = ft_isalnum(i);
      exp = isalnum(i);
      //assert
      TEST_ASSERT_EQUAL_INT32(exp, act);
      i++;
    }
}

int main()
{
  RUN_TEST(test_isalnum);
  return (UnityEnd());
}